const express = require('express');
const router = express.Router();

const Item  = require('../model/shop');

var total_price = 0; 

router.get('/', async (req, res) => {
   const items = await Item.find();
   res.json(items);
});

router.get('/total', async (req, res) => {  
    res.json(total_price);
 });

router.get('/:id', async (req, res) => {
    const item = await Item.findById(req.params.id);
    res.json(item);
 });

router.post ('/', async (req, res) =>{
    let { Producto , Cantidad , Precio } = req.body;
    let tot = parseInt(Precio)*parseInt(Cantidad);
    Precio = tot;
    const actualShop = new Item ({
        Producto,Cantidad,Precio
    });
    await actualShop.save();
    res.json({status : 'saved'});
});

router.put('/:id', async (req, res) => {
    let { Producto , Cantidad , Precio } = req.body;
    let tot = parseInt(Precio)*parseInt(Cantidad);
    //let tot = fir*parseInt(Precio);
    total_price = total_price+tot;
    Precio = tot;
    console.log(total_price);
    const newActualShop = { Producto,Cantidad,Precio };
    await Item.findByIdAndUpdate(req.params.id, newActualShop);
    res.json({status : 'Item updated'});
});

router.delete('/:id', async (req, res) => {
    await Item.findByIdAndRemove(req.params.id);
    res.json({status : 'Item deleted'});
});

module.exports = router; 