import React from 'react'
import { render } from 'react-dom';
import App from './App'

//lo monto donde esta mi id app
render(<App/>, document.getElementById('app'));

