import React, { Component }from 'react';

//Crea componente y lo uso en mi archivo principal
class App extends Component {

    //Estado de mi app
    constructor () {
        super();
        this.state = {
            Producto: '',
            Cantidad:'', 
            Precio: '',
            Productos: [],
            _id: '',
            precio_total: 0
        };
        //nueva función que nos permite manipular tanto su valor this como los parámetros que espera
        this.handleChange = this.handleChange.bind(this);
        this.agregarProducto = this.agregarProducto.bind(this);

    }

    
    
    agregarProducto(e) {
       if(this.state._id)  {
        fetch(`/api/shop/${this.state._id}`, {
            //metodo para actualizar
            method: 'PUT',
            //objeto a cambiar 
            body: JSON.stringify({
              Producto: this.state.Producto,
              Cantidad: this.state.Cantidad,
              Precio: this.state.Precio
            }),
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json'
            }
          })
            .then(res => res.json())
            .then(data => {
              window.M.toast({html: 'Producto actualizado'});
              this.setState({_id: '', Producto: '', Cantidad: '', Precio: ''});
              this.obtenerProductos();
            });

       } else {
           // evento del nav, envia peticion http al servidor
       fetch('/api/shop', {
        method: 'POST',
        //envio por post un objeto y lo convierto a un string
        body: JSON.stringify(this.state), 
        //le digo que el tipo de contenido es JSON
        headers: {
            'Accept' : 'application/json',
            'Content-Type': 'application/json'
        }
    })
    
    //como se que el servidor me va a retornar algo, uso una promesa
    //convierto la repsuesta a json y lo muestro x consola
         .then(res=> res.json())
         .then(data => {
             console.log(data)
             M.toast({html:'Producto guardado!'})
             this.setState({Producto: '', Cantidad:'', Precio: ''})
             //pido las tareas del servidor 
             this.obtenerProductos();
         })
         .catch(err =>console.error(err)); 
       }

         //evita que el metodo se refresque  
         e.preventDefault();
    }

        //apenas mi app este cargue utilice el obtenerProductos
    componentDidMount() {
        this.obtenerProductos();
    }

    obtenerProductos(){
        fetch('/api/shop')
        .then(res=> res.json())
        .then (data => {
            this.setState({Productos : data});
            console.log(this.state.Productos);
        });
    }

    obtenerTotal(){
        fetch('/api/shop')
        .then(res=> res.json())
        .then (data => {
            this.setState({Productos : data});
            console.log(this.state.Productos);
        });

    }

    deleteProduct(_id) {
        if (confirm('Deseas eliminar el producto?')) {
            //consulta al servidor
            fetch ('/api/shop/' + _id ,{
                method : 'DELETE',
                 //le digo que el tipo de contenido es JSON
               headers: {
                'Accept' : 'application/json',
                'Content-Type': 'application/json'
               }
            }) 
            //respuesta del servidor la convierto en un formato json
            .then(res=> res.json())
            .then (data => {
             console.log(data);
             M.toast({html:'Producto Eliminado'});
             this.obtenerProductos();
        });
        }
    }

    editarProducto (_id) {
        fetch ('/api/shop/' + _id )
        .then(res => res.json())
        .then(data => {
          console.log(data);
          this.setState({
            Producto: data.Producto,
            Cantidad: data.Cantidad,
            Precio: '0',
            _id: data._id
          });
        });
    
    }
    

    handleChange(e) {
        // del evento quiero su nombre y valor
        const { name , value } = e.target
        this.setState ({
            [name]: value
        });
    }

    render() {
        return (
            <div>
            {/*Navegacion*/}
                <nav className="light-blue darken-4">
                <div className="container">
                    <a className="logo" href="/">Shopping Cart</a>
                </div> 
                </nav>

             {/*Componente-Toda la app*/}
            <div className="container">
                <div className="row">
                   <div className="col s5">
                        <div className="card">
                            <div className="card-content">

                            <form onSubmit= {this.agregarProducto}>
                            <div className="row">
                            <div className="input-field col s12">
                                {/*corre cada vez que una tecla es oprimida para actualizar el estado de React*/}
                                <textarea name='Producto' onChange={this.handleChange} placeholder="Producto" value={this.state.Producto} className="materialize-textarea"></textarea>
                            </div>
                            <div className="input-field col s12">
                                <input name='Cantidad'onChange={this.handleChange} type="text" placeholder="Cantidad" value={this.state.Cantidad}></input>
                            </div>
                            <div className="input-field col s12">
                                <input name='Precio'  onChange={this.handleChange} type="text" placeholder="Precio unitario" value={this.state.Precio}></input>
                            </div>
                            </div>
                                <button type="submit" className="btn light-blue darken-4">
                                   Agregar producto
                                </button>
                                </form>
                    </div>

                    </div>

                    </div> 

                    <div className="col s7">
                        {/*tabla*/}
                        <table>
                            <thead>
                                <tr>
                                    <th>Producto</th>
                                    <th>Cantidad</th>
                                    <th>Precio</th>
                                </tr>
                            </thead>
                            <tbody>
                               {
                                   /*Recorro tareas y x cada una renderizo componente x pantalla*/
                                   this.state.Productos.map(Producto => {
                                       return (
                                           <tr key={Producto._id}>
                                               <td>{Producto.Producto}</td>
                                               <td>{Producto.Cantidad}</td>
                                               <td>{Producto.Precio}</td>
                                               <td>
                                                   <button onClick={() => this.editarProducto(Producto._id)} className="btn light-blue darken-4">
                                                    <i className="material-icons">edit</i>
                                                   </button>
                                                   <button className="btn light-blue darken-4" onClick={() => this.deleteProduct (Producto._id)} > 
                                                   <i className="material-icons" style={{margin: '6px'}}>delete</i>
                                                   </button>
                                               </td>
                                           </tr>
                                       )
                                   })
                               } 
                            </tbody>
                            
                        </table>
                    </div>
                </div>

            </div>
            </div>
        )
    }
}

export default App;