const mongoose = require('mongoose');
const { Schema } = mongoose;

const ShopSChema = new Schema({
    Producto: {type: String, required: true},
    Cantidad: {type: String, required: true},
    Precio: {type: String, required: true}   
})

module.exports = mongoose.model('Item', ShopSChema);

