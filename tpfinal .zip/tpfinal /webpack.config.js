module.exports = {
entry: './src/app/index.js',
output: {
    path: __dirname + '/src/public',
    filename: 'bundle.js'
},
    //traducir codigo moderno
    module : {
        rules: [
            //cada objeto es una config adicional a webpack
            {
                //babel loader, conecta WP con babel y traducir el codigo
               use: 'babel-loader', 
               //toma todos los archivos js que encuentre    
               test: /\.js$/,
               exclude: /node_modules/
            }
        ]
    }
}; 
