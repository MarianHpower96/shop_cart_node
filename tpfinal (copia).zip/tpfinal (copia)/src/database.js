const mongoose = require('mongoose');
const URI = 'mongodb+srv://root:root@cluster0-a0ioe.mongodb.net/test?retryWrites=true&w=majority';
mongoose.connect(URI)
   .then(db => console.log('DB is connected'))
   .catch(err => console.error(err));
 
module.exports = mongoose;     