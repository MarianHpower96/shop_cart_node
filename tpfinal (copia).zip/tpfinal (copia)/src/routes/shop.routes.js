const express = require('express');
const router = express.Router();

const Item  = require('../model/shop');

router.get('/', async (req, res) => {
   const items = await Item.find();
   res.json(items);
});

router.get('/:id', async (req, res) => {
    const item = await Item.findById(req.params.id);
    res.json(item);
 });

router.post ('/', async (req, res) =>{
    const { Producto , Cantidad , Precio } = req.body;
    const actualShop = new Item ({
        Producto,Cantidad,Precio
    });
    await actualShop.save();
    console.log(actualShop);
    res.json({status : 'saved'});
});

router.put('/:id', async (req, res) => {
    const { Producto , Cantidad , Precio } = req.body;
    const newActualShop = { Producto,Cantidad,Precio };
    await Item.findByIdAndUpdate(req.params.id, newActualShop);
    res.json({status : 'Item updated'});
});

router.delete('/:id', async (req, res) => {
    await Item.findByIdAndRemove(req.params.id);
    res.json({status : 'Item deleted'});
});

module.exports = router; 